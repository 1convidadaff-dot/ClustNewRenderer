# 🚀 Guia de Compilação do ClustNew Renderer

Este projeto é um plugin de renderização para o **Zalith Launcher**, focado em dispositivos com 4GB de RAM e suporte a OpenGL 2.1.

## 📂 Como montar o APK

1. **Android Studio**: Abra o projeto no Android Studio (Arctic Fox ou superior).
2. **Bibliotecas Nativas (.so)**: O código Java/Kotlin é apenas o "envelope". Para o renderizador funcionar, você precisa adicionar os arquivos binários do GL4ES.
   - Crie a pasta: `app/src/main/jniLibs/`
   - Dentro dela, crie pastas para cada arquitetura:
     - `arm64-v8a/`
     - `armeabi-v7a/`
     - `x86/`
     - `x86_64/`
   - Coloque o arquivo `libGL4es.so` dentro de cada uma dessas pastas.
3. **Build**: 
   - Vá em `Build` -> `Build Bundle(s) / APK(s)` -> `Build APK(s)`.

## ⚙️ Configurações Técnicas
- **Nome do Renderizador**: ClustNew
- **Base**: GL4ES (OpenGL -> OpenGL ES)
- **Alvo**: Android 8.0+ (minSdk 26)
- **RAM**: Otimizado para baixo consumo através do uso de `libGL4es.so` em vez de Vulkan/Zink.

## 🚀 Instalação
1. Instale o APK do **ClustNew** no seu Android.
2. Abra o **Zalith Launcher**.
3. Vá em `Configurações` -> `Gráficos/Renderizador`.
4. Selecione o **ClustNew** na lista de renderizadores instalados.
