plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    val nameId = "com.clustnew.renderer"
    namespace = nameId
    compileSdk = 34

    defaultConfig {
        applicationId = nameId
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.0.0-Turbo"
    }

    buildTypes {
        release {
            isMinifyEnabled = true // Habilitado para reduzir tamanho do APK e melhorar performance
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            
            resValue("string", "app_name", "ClustNew Turbo")
            
            // DEFINIÇÃO TURBO:
            // Usamos a libGL4es.so com flags de otimização máxima
            manifestPlaceholders["des"] = "ClustNew Turbo: Extreme FPS & Mod Compatibility for Legacy Devices"
            manifestPlaceholders["renderer"] = "ClustNew Turbo:libGL4es.so:libGL4es.so"
            
            // VARIÁVEIS DE AMBIENTE PARA DESEMPENHO MÁXIMO:
            // RENDERER_TYPE=GL4ES: Usa o tradutor mais leve
            // GL_VERSION=2.1: Garante compatibilidade com mods antigos
            // DISABLE_STRICT_GL=true: Ignora erros menores de GL para evitar crashes em mods
            // MEM_OPTIMIZE=true: Força a limpeza de cache de texturas
            // FPS_BOOST=true: Habilita renderização rápida
            manifestPlaceholders["pojavEnv"] = "RENDERER_TYPE=GL4ES:GL_VERSION=2.1:DISABLE_STRICT_GL=true:MEM_OPTIMIZE=true:FPS_BOOST=true:VRAM_PRIORITY=high"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
}
