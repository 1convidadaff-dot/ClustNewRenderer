package com.clustnew.renderer

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import android.view.Gravity
import android.graphics.Color
import android.widget.LinearLayout
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.Animation

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0A0A0A")) // Preto Profundo
            setPadding(60, 60, 60, 60)
        }

        val title = TextView(this).apply {
            text = "CLUSTNEW TURBO"
            textSize = 28f
            setTextColor(Color.parseColor("#00FFCC")) // Verde Neon
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }

        val status = TextView(this).apply {
            text = "🚀 STATUS: ENGINE ATIVADA\n⚡ MODO: ULTRA PERFORMANCE\n📦 COMPATIBILIDADE: MÁXIMA (MODS)\n💾 RAM: OTIMIZADA (4GB)"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 30)
            lineSpacingExtra = 8f
        }

        val footer = TextView(this).apply {
            text = "Sua máquina agora opera em modo de alta potência."
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
        }

        layout.addView(title)
        layout.addView(status)
        layout.addView(footer)

        setContentView(layout)

        Toast.makeText(this, "ClustNew Turbo: Sistema de Performance Ativado!", Toast.LENGTH_LONG).show()
    }
}
