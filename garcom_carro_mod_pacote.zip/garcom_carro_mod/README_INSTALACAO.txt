PACOTE: Garcom de Carro

CONTEUDO:
- garcom_carro_source.cs: codigo-fonte/base do script principal.
- garcom_carro.fxt: mensagens do mod.
- garcom_carro_touch_source.cs: base opcional para botao/menu touch em Android.

IMPORTANTE:
Este pacote nao contem um .csa binario compilado. O ambiente usado para montar estes arquivos nao possui compilador CLEO/Sanny Builder, entao eu nao posso afirmar que gerei um .csa pronto real. Para usar no jogo, compile garcom_carro_source.cs para garcom_carro.csa em um compilador compativel com GTA SA/CLEO.

COMO COMPILAR:
1. Abra garcom_carro_source.cs no Sanny Builder ou compilador CLEO compativel.
2. Selecione GTA San Andreas como alvo.
3. Compile como CLEO script .csa.
4. Se algum opcode nao compilar no seu pack Android, ajuste pelo opcode equivalente indicado nos comentarios.
5. Salve o binario final como garcom_carro.csa.

INSTALACAO ANDROID:
1. Copie garcom_carro.csa para a pasta CLEO do GTA SA Android.
2. Copie garcom_carro.fxt para CLEO_TEXT, se seu CLEO usar essa pasta.
3. Em alguns CLEO loaders, o .fxt tambem pode ficar dentro da pasta CLEO.
4. O caminho pode variar conforme versao do GTA SA, Android, CLEO Mod e gerenciador de arquivos.

INSTALACAO PC:
1. Copie garcom_carro.csa para a pasta CLEO do GTA San Andreas.
2. Copie garcom_carro.fxt para CLEO_TEXT.

TESTE RAPIDO:
1. Entre no jogo com CJ a pe.
2. Ative o script pelo comando configurado.
3. Aguarde a limousine aparecer.
4. Entre/espere o CJ ser colocado no banco traseiro.
5. Marque um destino no mapa.
6. Aperte novamente o comando de iniciar viagem.
7. Confira se o motorista dirige ate o destino, CJ sai e a limousine vai embora.

OBSERVACOES:
- Para Android, pode ser necessario trocar a ativacao por botao touch especifico do seu CLEO.
- O opcode de waypoint e o opcode de dirigir ate coordenadas variam entre compiladores.
- Recomenda-se testar primeiro sem outros mods de trafego, passageiros ou controle de veiculos.
