{$CLEO .csa}
0000: NOP

// ============================================================
// MOD: Garcom de Carro / Motorista Particular do CJ
// Plataforma alvo: GTA San Andreas classico + CLEO / CLEO Android
// Arquivo final recomendado apos compilar: garcom_carro.csa
//
// IMPORTANTE:
// Este arquivo e CODIGO-FONTE/base em estilo Sanny Builder/CLEO.
// Ele precisa ser compilado para virar um .csa binario real.
// Alguns opcodes podem variar conforme o compilador/CLEO Android usado.
// ============================================================

// CONTROLES DA BASE:
// PC/Sanny: tecla G chama o motorista e tambem inicia a viagem apos marcar waypoint.
// Android: substitua o bloco 0AB0 por botao/menu do seu CLEO ou por um .csi touch.

thread 'GARCOM'

// Estados:
// 0 = aguardando chamada
// 1 = limousine criada / aguardando CJ entrar
// 2 = aguardando waypoint no mapa
// 3 = viajando ate o waypoint
// 4 = finalizando / motorista indo embora

0@ = 0          // estado
1@ = -1         // carro limo
2@ = -1         // motorista
3@ = 0          // flag waypoint
4@ = 0.0        // destino X
5@ = 0.0        // destino Y
6@ = 0.0        // destino Z
7@ = 0.0        // spawn X
8@ = 0.0        // spawn Y
9@ = 0.0        // spawn Z
10@ = 0         // cooldown

:MAIN
wait 0
if
  Player.Defined($PLAYER_CHAR)
else_jump @MAIN

// Pequeno cooldown para nao ativar varias vezes no mesmo toque/tecla.
if
  10@ > 0
then
  10@ -= 1
end

// Ativacao base por tecla G no PC. No Android, trocar por botao CLEO/touch.
if and
  10@ == 0
  0AB0: key_pressed 71
then
  10@ = 60
  if
    0@ == 0
  then
    gosub @CHAMAR_MOTORISTA
  else
    if
      0@ == 2
    then
      gosub @TENTAR_INICIAR_VIAGEM
    end
  end
end

if
  0@ == 1
then
  gosub @PROCESSAR_ENTRADA
end

if
  0@ == 2
then
  gosub @MOSTRAR_AGUARDANDO_DESTINO
end

if
  0@ == 3
then
  gosub @PROCESSAR_VIAGEM
end

if
  0@ == 4
then
  gosub @LIMPAR_FINAL
end

jump @MAIN

// ============================================================
// CHAMADA DO MOTORISTA
// ============================================================
:CHAMAR_MOTORISTA
Model.Load(#STRETCH)
Model.Load(#WMYCH)
038B: load_requested_models

// Pega posicao do CJ e cria a limo alguns metros a frente/lado.
Actor.StorePos($PLAYER_ACTOR, 7@, 8@, 9@)
7@ += 8.0
8@ += 4.0

00A5: 1@ = create_car #STRETCH at 7@ 8@ 9@
0229: set_car 1@ primary_color_to 0 secondary_color_to 0
0186: 11@ = create_marker_above_car 1@
0165: set_marker 11@ color_to 1

// Cria motorista ja no banco do motorista.
0129: 2@ = create_actor_pedtype 4 model #WMYCH in_car 1@ driverseat
01C8: actor 2@ health = 999
02AB: set_actor 2@ immunities BP 1 FP 1 EP 1 CP 1 MP 1

03E5: show_text_box 'GC01'
wait 1200
03E5: show_text_box 'GC02'
0@ = 1
return

// ============================================================
// ENTRADA DO CJ NA LIMOUSINE
// ============================================================
:PROCESSAR_ENTRADA
if or
  not Car.Defined(1@)
  not Actor.Defined(2@)
then
  gosub @RESET_MOD
  return
end

// Quando CJ estiver perto, coloca ele no banco traseiro/direito.
if
  00FE: actor $PLAYER_ACTOR sphere 0 in_sphere 7@ 8@ 9@ radius 6.0 6.0 3.0
then
  // Em alguns CLEO/Sanny, este opcode pode variar para 'put_actor_in_car_as_passenger'.
  // Ajuste o assento se o CJ aparecer no lugar errado.
  036A: put_actor $PLAYER_ACTOR in_car 1@
  wait 800
  03E5: show_text_box 'GC03'
  wait 1500
  03E5: show_text_box 'GC04'
  0@ = 2
end
return

// ============================================================
// AGUARDANDO WAYPOINT
// ============================================================
:MOSTRAR_AGUARDANDO_DESTINO
// Mostra lembrete de tempos em tempos.
if
  10@ == 0
then
  03E5: show_text_box 'GC05'
  10@ = 180
end
return

:TENTAR_INICIAR_VIAGEM
// CLEO opcode comum para pegar o marcador/waypoint do mapa.
// Em alguns compiladores aparece como: 0AB6: store_target_marker_coords_to 4@ 5@ 6@
0AB6: store_target_marker_coords_to 4@ 5@ 6@

// Validacao simples: coordenadas nulas normalmente indicam que nao ha marcador.
if or
  4@ <> 0.0
  5@ <> 0.0
then
  03E5: show_text_box 'GC06'
  wait 800
  gosub @INICIAR_AUTOPILOTO
else
  03E5: show_text_box 'GC07'
end
return

// ============================================================
// AUTOPILOTO
// ============================================================
:INICIAR_AUTOPILOTO
if or
  not Car.Defined(1@)
  not Actor.Defined(2@)
then
  gosub @RESET_MOD
  return
end

// Mantem CJ sem controle durante a viagem para evitar bugs.
Player.CanMove($PLAYER_CHAR) = False
00AD: set_car 1@ max_speed_to 28.0
00AE: set_car 1@ driving_style_to 2
00A8: set_car 1@ to_psycho_driver

// Comando base de dirigir ate coordenadas. Dependendo do Sanny/CLEO,
// o nome do opcode pode aparecer como car_drive_to, car_goto_coordinates
// ou similar. Se nao compilar, substitua pelo comando equivalente do seu opcode DB.
02C2: car 1@ drive_to 4@ 5@ 6@

03E5: show_text_box 'GC08'
0@ = 3
return

:PROCESSAR_VIAGEM
if or
  not Car.Defined(1@)
  not Actor.Defined(2@)
then
  gosub @RESET_MOD
  return
end

// Se a limo chegou perto do destino, encerra a viagem.
if
  00FE: actor $PLAYER_ACTOR sphere 0 in_sphere 4@ 5@ 6@ radius 18.0 18.0 8.0
then
  03E5: show_text_box 'GC09'
  wait 700
  Player.CanMove($PLAYER_CHAR) = True
  // Faz CJ sair. Em alguns compiladores, use o opcode AS_actor exit_car.
  05CD: AS_actor $PLAYER_ACTOR exit_car 1@
  wait 2500
  gosub @MOTORISTA_IR_EMBORA
end
return

// ============================================================
// FINALIZACAO
// ============================================================
:MOTORISTA_IR_EMBORA
if
  Car.Defined(1@)
then
  12@ = 4@
  13@ = 5@
  14@ = 6@
  12@ += 90.0
  13@ += 90.0
  00AD: set_car 1@ max_speed_to 35.0
  02C2: car 1@ drive_to 12@ 13@ 14@
end
03E5: show_text_box 'GC10'
0@ = 4
10@ = 220
return

:LIMPAR_FINAL
if
  10@ > 0
then
  return
end
if
  Actor.Defined(2@)
then
  Actor.DestroyInstantly(2@)
end
if
  Car.Defined(1@)
then
  Car.Destroy(1@)
end
gosub @RESET_MOD
return

:RESET_MOD
Player.CanMove($PLAYER_CHAR) = True
0@ = 0
1@ = -1
2@ = -1
3@ = 0
4@ = 0.0
5@ = 0.0
6@ = 0.0
10@ = 80
Model.Destroy(#STRETCH)
Model.Destroy(#WMYCH)
return
