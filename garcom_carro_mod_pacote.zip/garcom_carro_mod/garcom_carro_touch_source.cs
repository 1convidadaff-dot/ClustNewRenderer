{$CLEO .csi}
0000: NOP

// ============================================================
// MOD: Garcom de Carro - Botao/Menu Touch opcional
// Arquivo final recomendado apos compilar: garcom_carro_touch.csi
//
// Esta e uma BASE para Android: a sintaxe de botao/menu visual muda muito
// entre CLEO Android, CLEO Mod, compiladores e packs de botoes.
// Use este arquivo para ligar um botao visual ao mesmo fluxo do .csa.
// ============================================================

thread 'GCTOUCH'

:MAIN
wait 0

// MODELO DE LOGICA:
// 1) Botao "Chamar Garcom" executa o mesmo bloco CHAMAR_MOTORISTA do .csa.
// 2) Botao "Iniciar Viagem" executa TENTAR_INICIAR_VIAGEM.
// 3) Se o seu CLEO usa comando de touch/tap especifico, coloque aqui.
//
// Exemplo conceitual:
// if
//   TOUCH_BUTTON_PRESSED 'GC_CALL'
// then
//   gosub @CHAMAR_MOTORISTA
// end
//
// if
//   TOUCH_BUTTON_PRESSED 'GC_GO'
// then
//   gosub @TENTAR_INICIAR_VIAGEM
// end

jump @MAIN
